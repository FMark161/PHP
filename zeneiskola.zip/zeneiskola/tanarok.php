<?php

include('connect.php');




if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    $nev= $_POST['nev'];
$hangszerek= $_POST['hangszerek'];
$telefon= $_POST['telefon'];
$email= $_POST['email'];
$iskolaid= $_POST['iskolaid'];
$nem= $_POST['nem'];
 
   
    

    $sql = "INSERT INTO tanarok (nev, hangszerek, telefon, email, iskolaid, nem) 
            VALUES ('$nev', '$hangszerek', '$telefon', '$email', '$iskolaid', '$nem')"; 
echo $sql;
    if ($conn->query($sql) === TRUE) {
        echo "<p style='color:green;'>Sikeres mentés!</p>";
    } else {
        echo "<p style='color:red;'>Hiba: " . $conn->error . "</p>";
    }
}

$conn->close();
?>
 <form action="" method="post">
      <h2>Tanár hozzáadása</h2>

      <div class="input-field">
        <label>Név:</label>
        <input type="text" name="nev" required />
        
      </div>

      <div class="input-field">
        <label>Hangszer:</label>
        <input type="text" name="hangszerek" required />
        
      </div>

      <div class="input-field">
        <label>Telefon:</label>
        <input type="text" name="telefon" required />
        
      </div>

      <div class="input-field">
        <label>Email:</label>
        <input type="text" name="email" required />
        
      </div>

      <div class="input-field">
        <label>Iskola_id:</label>
        <input type="text" name="iskolaid" required />
        
      </div>

      <div class="input-field">
        <label>Nem:</label>
        <input type="text" name="nem" required />
        
      </div>
 
      <button type="submit" id="button" >Elküldés</button>

</form>