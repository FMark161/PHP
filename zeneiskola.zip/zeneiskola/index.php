<?php
include('connect.php');


if (isset($_GET['p'])) {
    $p = $_GET['p'];
} else
    $p = "";

$sql = "SELECT * FROM menu WHERE link LIKE '" . $conn->real_escape_string($p) . "'";

$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $tartalom = $row['tartalom'];
    }
}
?>

<html lang="hu">

<head>
    <link rel="icon" type="image/png" href="violinKulcs.jpg">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zenélj Velünk | Zeneiskola és Hangszerek</title>
    
    <?php include('style.html'); ?>
</head>

<body>
    <header>
        <div class="container">
            <div class="header-content">
                <div class="logo">
                   <img src="violinKulcs.jpg" alt="Zenélj Velünk logo" class="logo-image">
                    <h1>Zenélj Velünk</h1>
                </div>
                <button class="mobile-menu-btn">☰</button>
                <nav>
                    <?php include('menu.php'); ?>
                </nav>
            </div>
        </div>
    </header>

    <!-- Kezdőlap -->
    <div id="home" class="page-content active">
        <section class="hero">
            <div class="container">
                <div class="hero-content">
                    <h2>Fedezd fel a zene világát velünk!</h2>
                    <p>Minőségi oktatás, szakértő tanárok és kiváló hangszerek várnak, hogy segítsenek zenei
                        utazásodban.</p>
                    <a href="#" class="btn" data-page="zeneiskola">Tudj meg többet</a>
                </div>
            </div>
        </section>

        
 <!--Tartalom kiírása-->
            <?php echo($tartalom); ?>
          

        <section>
            <div class="container">
                <h2 class="section-title">Miért válassz minket?</h2>
                <div class="cards">
                    <div class="card">
                        <div class="card-img"
                            style="background-image: url('https://images.unsplash.com/photo-1571974599782-87624638275f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')">
                        </div>
                        <div class="card-content">
                            <h3>Szakértő tanárok</h3>
                            <p>Tapasztalt, diplomás oktatóink személyre szabott módszerekkel segítik zenei fejlődésedet.
                            </p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-img"
                            style="background-image: url('https://images.unsplash.com/photo-1511735111819-9a3f7709049c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')">
                        </div>
                        <div class="card-content">
                            <h3>Kiváló hangszerek</h3>
                            <p>Minőségi, jól karbantartott hangszereket kínálunk oktatásra és kölcsönzésre.</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-img"
                            style="background-image: url('https://images.unsplash.com/photo-1494232410401-ad00d5433cfa?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')">
                        </div>
                        <div class="card-content">
                            <h3>Rugalmas időbeosztás</h3>
                            <p>Óráidat igazíthatod egyéni időbeosztásodhoz, akár hétvégén is.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section style="background-color: #EDE1CD;">
            <div class="container">
                <h2 class="section-title">Gyors információk</h2>
                <div class="cards">
                    <div class="card">
                        <div class="card-content">
                            <h3>Nyitvatartás</h3>
                            <p>Hétfő - Péntek: 9:00 - 18:00</p>
                            <p>Szombat: 10:00 - 14:00</p>
                            <p>Vasárnap: Zárt</p>
                            <a href="#" class="btn" data-page="zeneiskola">További információk</a>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-content">
                            <h3>Közelgő események</h3>
                            <p><strong>Tanulói koncert</strong> - Május 15.</p>
                            <p><strong>Mesterkurzus gitáron</strong> - Május 22.</p>
                            <p><strong>Nyílt nap</strong> - Június 5.</p>
                            <a href="#" class="btn" data-page="esemenyek">Összes esemény</a>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-content">
                            <h3>Kapcsolat</h3>
                            <p>1056 Budapest, Zene utca 12.</p>
                            <p>Telefon: +36 1 234 5678</p>
                            <p>Email: info@zeneljvelunk.hu</p>
                            <a href="#" class="btn">Írj nekünk</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- Zeneiskola oldal -->
    <div id="zeneiskola" class="page-content">
        <section class="page-hero">
            <div class="container">
                <h2>Zeneiskola</h2>
                <p>Minőségi zenei oktatás minden korosztály számára</p>
            </div>
        </section>

        <section>
            <div class="container">
                <h2 class="section-title">Kurzusaink</h2>
                <div class="cards">
                    <div class="card">
                        <div class="card-img"
                            style="background-image: url('https://images.unsplash.com/photo-1571974599782-87624638275f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')">
                        </div>
                        <div class="card-content">
                            <h3>Kezdő kurzusok</h3>
                            <p>Akár most kezded a zenei tanulmányaidat, nálunk megtalálod a számodra megfelelő kezdő
                                kurzust. Minden korosztály számára kínálunk oktatást.</p>
                            <a href="#" class="btn">Jelentkezem</a>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-img"
                            style="background-image: url('https://images.unsplash.com/photo-1511735111819-9a3f7709049c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')">
                        </div>
                        <div class="card-content">
                            <h3>Haladó kurzusok</h3>
                            <p>Már van zenei alapod, és szeretnél tovább fejlődni? Haladó kurzusaink segítenek a
                                technikai készségeid és zenei tudásod bővítésében.</p>
                            <a href="#" class="btn">Tovább fejlődök</a>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-img"
                            style="background-image: url('https://images.unsplash.com/photo-1494232410401-ad00d5433cfa?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')">
                        </div>
                        <div class="card-content">
                            <h3>Zeneelmélet</h3>
                            <p>Ismerd meg a zene alapvető elemeit, az összhangzattant, a ritmust és a formákat.
                                Elmélkedő kurzusaink mélyebb betekintést nyújtanak a zene világába.</p>
                            <a href="#" class="btn">Tanulj elméletet</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section style="background-color: #f0f5f9;">
            <div class="container">
                <h2 class="section-title">Áraink</h2>
                <div class="cards">
                    <div class="card">
                        <div class="card-content">
                            <h3>Csoportos óra</h3>
                            <p>Kis csoportokban (3-5 fő) történő oktatás</p>
                            <p><strong>8.000 Ft/óra</strong></p>
                            <a href="#" class="btn">Jelentkezés</a>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-content">
                            <h3>Egyéni óra</h3>
                            <p>Személyre szabott, egyéni oktatás</p>
                            <p><strong>12.000 Ft/óra</strong></p>
                            <a href="#" class="btn">Jelentkezés</a>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-content">
                            <h3>Családi kedvezmény</h3>
                            <p>Családtagok esetén 15% kedvezmény minden további jelentkezőre</p>
                            <a href="#" class="btn">Részletek</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- Tanárok oldal -->
    <div id="tanarok" class="page-content">
        <section class="page-hero">
            <div class="container">
                <h2>Tanárok</h2>
                <p>Ismerd meg kiváló oktatóinkat</p>
            </div>
        </section>

        <section>
            <div class="container">
                <h2 class="section-title">Tanári karunk</h2>

                <div class="teacher-profile">
                    <div class="teacher-img"
                        style="background-image: url('https://images.unsplash.com/photo-1516280030429-27679b3dc9cf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')">
                    </div>
                    <div class="teacher-info">
                        <h3>Kovács Anna</h3>
                        <p><strong>Zongora tanár</strong></p>
                        <p>15 év tapasztalattal. Zeneművész diplomája van a Liszt Ferenc Zeneművészeti Egyetemről.
                            Számos díjazott tanulója volt országos versenyeken.</p>
                        <p><strong>Oktatott hangszerek:</strong> Zongora, billentyűs hangszerek</p>
                    </div>
                </div>

                <div class="teacher-profile">
                    <div class="teacher-img"
                        style="background-image: url('https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')">
                    </div>
                    <div class="teacher-info">
                        <h3>Nagy Péter</h3>
                        <p><strong>Gitár tanár</strong></p>
                        <p>10 éve oktat és számos koncerten vett részt hazai és nemzetközi fesztiválokon. Saját
                            együttese van, amely folk-rock stílusban játszik.</p>
                        <p><strong>Oktatott hangszerek:</strong> Akusztikus gitár, elektromos gitár, basszusgitár</p>
                    </div>
                </div>

                <div class="teacher-profile">
                    <div class="teacher-img"
                        style="background-image: url('https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')">
                    </div>
                    <div class="teacher-info">
                        <h3>Szabó Eszter</h3>
                        <p><strong>Hegedű tanár</strong></p>
                        <p>A Budapesti Fesztiválzenekar tagja. Kiemelkedő oktatási módszereiről ismert. Tanítványai
                            rendszeresen szerepelnek ifjúsági zenekarokban.</p>
                        <p><strong>Oktatott hangszerek:</strong> Hegedű, brácsa</p>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- Kölcsönzés oldal -->
    <div id="kolcsonzes" class="page-content">
        <section class="page-hero">
            <div class="container">
                <h2>Hangszerkölcsönzés</h2>
                <p>Minőségi hangszerek bérbeadása kedvező áron</p>
            </div>
        </section>

        <section>
            <div class="container">
                <h2 class="section-title">Hogyan működik?</h2>
                <div class="cards">
                    <div class="card">
                        <div class="card-content">
                            <h3>Kölcsönzési feltételek</h3>
                            <p>Kölcsönözhetsz hangszereket tanulásra vagy előadásokra. A kölcsönzési időtartam 1
                                hónaptól 1 évig terjedhet.</p>
                            <ul style="margin-left: 1.5rem; margin-top: 1rem;">
                                <li>Minőségi, jól karbantartott hangszerek</li>
                                <li>Rugalmas időtartam</li>
                                <li>Kedvező árak</li>
                                <li>Szakképzett személyzet tanácsadással</li>
                            </ul>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-content">
                            <h3>Áraink</h3>
                            <p>Kölcsönzési díjaink a hangszer típusától és a kölcsönzés időtartamától függően változnak.
                            </p>
                            <table style="width: 100%; margin-top: 1rem; border-collapse: collapse;">
                                <tr style="border-bottom: 1px solid #eee;">
                                    <td style="padding: 0.5rem 0;">Zongora</td>
                                    <td style="text-align: right;">15.000 Ft/hó</td>
                                </tr>
                                <tr style="border-bottom: 1px solid #eee;">
                                    <td style="padding: 0.5rem 0;">Gitár</td>
                                    <td style="text-align: right;">5.000 Ft/hó</td>
                                </tr>
                                <tr style="border-bottom: 1px solid #eee;">
                                    <td style="padding: 0.5rem 0;">Hegedű</td>
                                    <td style="text-align: right;">7.000 Ft/hó</td>
                                </tr>
                                <tr>
                                    <td style="padding: 0.5rem 0;">Fuvola</td>
                                    <td style="text-align: right;">4.000 Ft/hó</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section style="background-color: #f0f5f9;">
            <div class="container">
                <h2 class="section-title">Kölcsönzési kérelm</h2>
                <div class="rental-form">
                    <form id="rentalForm">
                        <div class="form-group">
                            <label for="name">Név</label>
                            <input type="text" id="name" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email cím</label>
                            <input type="email" id="email" required>
                        </div>
                        <div class="form-group">
                            <label for="phone">Telefonszám</label>
                            <input type="tel" id="phone" required>
                        </div>
                        <div class="form-group">
                            <label for="instrument">Hangszer</label>
                            <select id="instrument" required>
                                <option value="">Válassz hangszert</option>
                                <option value="zongora">Zongora</option>
                                <option value="gitar">Gitár</option>
                                <option value="hegedu">Hegedű</option>
                                <option value="fuvola">Fuvola</option>
                                <option value="dob">Dob</option>
                                <option value="szaxofon">Szaxofon</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="duration">Kölcsönzési időtartam</label>
                            <select id="duration" required>
                                <option value="">Válassz időtartamot</option>
                                <option value="1">1 hónap</option>
                                <option value="3">3 hónap</option>
                                <option value="6">6 hónap</option>
                                <option value="12">1 év</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="message">Egyéb megjegyzések</label>
                            <textarea id="message"></textarea>
                        </div>
                        <button type="submit" class="btn">Kölcsönzési kérelem elküldése</button>
                    </form>
                </div>
            </div>
        </section>
    </div>

    <!-- További oldalak vázai... -->
    <!-- Diák, Elérhető hangszerek, Események, Hangszerek oldalak hasonló struktúrával készülnek -->

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Kapcsolat</h3>
                    <p>Zenélj Velünk Zeneiskola</p>
                    <p>1056 Budapest, Zene utca 12.</p>
                    <p>Telefon: +36 1 234 5678</p>
                    <p>Email: info@zeneljvelunk.hu</p>
                </div>
                <div class="footer-section">
                    <h3>Nyitvatartás</h3>
                    <p>Hétfő - Péntek: 9:00 - 18:00</p>
                    <p>Szombat: 10:00 - 14:00</p>
                    <p>Vasárnap: Zárt</p>
                </div>
                <div class="footer-section">
                    <h3>Gyors linkek</h3>
                    <ul>
                        <li><a href="#" data-page="home">Kezdőlap</a></li>
                        <li><a href="#" data-page="zeneiskola">Zeneiskola</a></li>
                        <li><a href="#" data-page="tanarok">Tanárok</a></li>
                        <li><a href="#" data-page="kolcsonzes">Kölcsönzés</a></li>
                        <li><a href="#" data-page="diak">Diák</a></li>
                        <li><a href="#" data-page="hangszerek">Hangszerek</a></li>
                        <li><a href="#" data-page="esemenyek">Események</a></li>
                    </ul>
                </div>
            </div>
            <div class="copyright">
                <p>&copy; 2025 Zenélj Velünk Zeneiskola. Minden jog fenntartva.</p>
            </div>
        </div>
    </footer>

    <script>
        // Oldalak közötti navigáció
       

        // Mobilos menü kezelése
        document.querySelector('.mobile-menu-btn').addEventListener('click', function () {
            document.getElementById('main-menu').classList.toggle('show');
        });

        // Kölcsönzési űrlap kezelése
        document.getElementById('rentalForm').addEventListener('submit', function (e) {
            e.preventDefault();
            alert('Köszönjük kölcsönzési kérelmét! Hamarosan felvesszük Önnel a kapcsolatot.');
            this.reset();
        });
    </script>
</body>

</html>