<?php
include('connect.php');

if (isset($_GET['p'])) {
    $p = $_GET['p'];
} else {
    $p = "home"; // Alapértelmezett oldal
}

$tartalom = ""; // Alapértelmezett érték

$sql = "SELECT * FROM menu WHERE link LIKE '" . $conn->real_escape_string($p) . "'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $tartalom = $row['tartalom'];
    }
}

// Aktív oldal meghatározása a navigációhoz
$active_page = $p;
?>

<html lang="hu">

<head>
    <link rel="icon" type="image/png" href="violinKulcs.jpg">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zenélj Velünk | Zeneiskola és Hangszerek</title>

    <?php include('style.html'); ?>
</head>

<body>
    <header>
        <div class="container">
            <div class="header-content">
                <div class="logo">
                    <img src="violinKulcs.jpg" alt="Zenélj Velünk logo" class="logo-image">
                    <h1>Zenélj Velünk</h1>
                </div>
                <button class="mobile-menu-btn">☰</button>
                <nav>
                    <?php include('menu.php'); ?>
                </nav>
            </div>
        </div>
    </header>

    <!-- Kezdőlap -->
    <div id="home" class="page-content <?php echo ($active_page == 'home') ? 'active' : ''; ?>">
        <section class="hero">
            <div class="container">
                <div class="hero-content">
                    <h2>Fedezd fel a zene világát velünk!</h2>
                    <p>Minőségi oktatás, szakértő tanárok és kiváló hangszerek várnak, hogy segítsenek zenei
                        utazásodban.</p>
                    <a href="#" class="btn" data-page="zeneiskola">Tudj meg többet</a>
                </div>
            </div>
        </section>

        <!-- Tartalom kiírása -->
        <?php echo $tartalom; ?>

        <section>
            <div class="container">
                <h2 class="section-title">Miért válassz minket?</h2>
                <div class="cards">
                    <div class="card">
                        <div class="card-img"
                            style="background-image: url('https://images.unsplash.com/photo-1571974599782-87624638275f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')">
                        </div>
                        <div class="card-content">
                            <h3>Szakértő tanárok</h3>
                            <p>Tapasztalt, diplomás oktatóink személyre szabott módszerekkel segítik zenei fejlődésedet.
                            </p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-img"
                            style="background-image: url('https://images.unsplash.com/photo-1511735111819-9a3f7709049c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')">
                        </div>
                        <div class="card-content">
                            <h3>Kiváló hangszerek</h3>
                            <p>Minőségi, jól karbantartott hangszereket kínálunk oktatásra és kölcsönzésre.</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-img"
                            style="background-image: url('https://images.unsplash.com/photo-1494232410401-ad00d5433cfa?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')">
                        </div>
                        <div class="card-content">
                            <h3>Rugalmas időbeosztás</h3>
                            <p>Óráidat igazíthatod egyéni időbeosztásodhoz, akár hétvégén is.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section style="background-color: #EDE1CD;">
            <div class="container">
                <h2 class="section-title">Gyors információk</h2>
                <div class="cards">
                    <div class="card">
                        <div class="card-content">
                            <h3>Nyitvatartás</h3>
                            <p>Hétfő - Péntek: 9:00 - 18:00</p>
                            <p>Szombat: 10:00 - 14:00</p>
                            <p>Vasárnap: Zárt</p>
                            <a href="#" class="btn" data-page="zeneiskola">További információk</a>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-content">
                            <h3>Közelgő események</h3>
                            <p><strong>Tanulói koncert</strong> - Május 15.</p>
                            <p><strong>Mesterkurzus gitáron</strong> - Május 22.</p>
                            <p><strong>Nyílt nap</strong> - Június 5.</p>
                            <a href="#" class="btn" data-page="esemenyek">Összes esemény</a>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-content">
                            <h3>Kapcsolat</h3>
                            <p>1056 Budapest, Zene utca 12.</p>
                            <p>Telefon: +36 1 234 5678</p>
                            <p>Email: info@zeneljvelunk.hu</p>
                            <a href="#" class="btn">Írj nekünk</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- Zeneiskola oldal -->
    <div id="zeneiskola" class="page-content <?php echo ($active_page == 'zeneiskola') ? 'active' : ''; ?>">
        <section class="page-hero">
            <div class="container">
                <h2>Zeneiskola</h2>
                <p>Minőségi zenei oktatás minden korosztály számára</p>
            </div>
        </section>

        <section>
            <div class="container">
                <h2 class="section-title">Kurzusaink</h2>
                <div class="cards">
                    <div class="card">
                        <div class="card-img"
                            style="background-image: url('https://images.unsplash.com/photo-1571974599782-87624638275f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')">
                        </div>
                        <div class="card-content">
                            <h3>Kezdő kurzusok</h3>
                            <p>Akár most kezded a zenei tanulmányaidat, nálunk megtalálod a számodra megfelelő kezdő
                                kurzust. Minden korosztály számára kínálunk oktatást.</p>
                            <a href="#" class="btn">Jelentkezem</a>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-img"
                            style="background-image: url('https://images.unsplash.com/photo-1511735111819-9a3f7709049c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')">
                        </div>
                        <div class="card-content">
                            <h3>Haladó kurzusok</h3>
                            <p>Már van zenei alapod, és szeretnél tovább fejlődni? Haladó kurzusaink segítenek a
                                technikai készségeid és zenei tudásod bővítésében.</p>
                            <a href="#" class="btn">Tovább fejlődök</a>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-img"
                            style="background-image: url('https://images.unsplash.com/photo-1494232410401-ad00d5433cfa?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')">
                        </div>
                        <div class="card-content">
                            <h3>Zeneelmélet</h3>
                            <p>Ismerd meg a zene alapvető elemeit, az összhangzattant, a ritmust és a formákat.
                                Elmélkedő kurzusaink mélyebb betekintést nyújtanak a zene világába.</p>
                            <a href="#" class="btn">Tanulj elméletet</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section style="background-color:  #d8cab3ff;">
            <div class="container">
                <h2 class="section-title">Áraink</h2>
                <div class="cards">
                    <div class="card">
                        <div class="card-content">
                            <h3>Csoportos óra</h3>
                            <p>Kis csoportokban (3-5 fő) történő oktatás</p>
                            <p><strong>8.000 Ft/óra</strong></p>
                            <a href="#" class="btn">Jelentkezés</a>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-content">
                            <h3>Egyéni óra</h3>
                            <p>Személyre szabott, egyéni oktatás</p>
                            <p><strong>12.000 Ft/óra</strong></p>
                            <a href="#" class="btn">Jelentkezés</a>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-content">
                            <h3>Családi kedvezmény</h3>
                            <p>Családtagok esetén 15% kedvezmény minden további jelentkezőre</p>
                            <a href="#" class="btn">Részletek</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- Tanárok oldal -->
    <div id="tanarok" class="page-content <?php echo ($active_page == 'tanarok') ? 'active' : ''; ?>">
        <section class="page-hero">
            <div class="container">
                <h2>Tanárok</h2>
                <p>Ismerd meg kiváló oktatóinkat</p>
            </div>
        </section>

        <section>
            <div class="container">
                <h2 class="section-title">Tanári karunk</h2>

                <div class="teacher-profile">
                    <div class="teacher-img"
                        style="background-image: url('https://images.unsplash.com/photo-1516280030429-27679b3dc9cf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')">
                    </div>
                    <div class="teacher-info">
                        <h3>Kovács Anna</h3>
                        <p><strong>Zongora tanár</strong></p>
                        <p>15 év tapasztalattal. Zeneművész diplomája van a Liszt Ferenc Zeneművészeti Egyetemről.
                            Számos díjazott tanulója volt országos versenyeken.</p>
                        <p><strong>Oktatott hangszerek:</strong> Zongora, billentyűs hangszerek</p>
                    </div>
                </div>

                <div class="teacher-profile">
                    <div class="teacher-img"
                        style="background-image: url('https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')">
                    </div>
                    <div class="teacher-info">
                        <h3>Nagy Péter</h3>
                        <p><strong>Gitár tanár</strong></p>
                        <p>10 éve oktat és számos koncerten vett részt hazai és nemzetközi fesztiválokon. Saját
                            együttese van, amely folk-rock stílusban játszik.</p>
                        <p><strong>Oktatott hangszerek:</strong> Akusztikus gitár, elektromos gitár, basszusgitár</p>
                    </div>
                </div>

                <div class="teacher-profile">
                    <div class="teacher-img"
                        style="background-image: url('https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')">
                    </div>
                    <div class="teacher-info">
                        <h3>Szabó Eszter</h3>
                        <p><strong>Hegedű tanár</strong></p>
                        <p>A Budapesti Fesztiválzenekar tagja. Kiemelkedő oktatási módszereiről ismert. Tanítványai
                            rendszeresen szerepelnek ifjúsági zenekarokban.</p>
                        <p><strong>Oktatott hangszerek:</strong> Hegedű, brácsa</p>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- Kölcsönzés oldal -->
    <div id="kolcsonzes" class="page-content <?php echo ($active_page == 'kolcsonzes') ? 'active' : ''; ?>">
        <section class="page-hero">
            <div class="container">
                <h2>Hangszerkölcsönzés</h2>
                <p>Minőségi hangszerek bérbeadása kedvező áron</p>
            </div>
        </section>

        <section>
            <div class="container">
                <h2 class="section-title">Hogyan működik?</h2>
                <div class="cards">
                    <div class="card">
                        <div class="card-content">
                            <h3>Kölcsönzési feltételek</h3>
                            <p>Kölcsönözhetsz hangszereket tanulásra vagy előadásokra. A kölcsönzési időtartam 1
                                hónaptól 1 évig terjedhet.</p>
                            <ul class="feature-list">
                                <li>Minőségi, jól karbantartott hangszerek</li>
                                <li>Rugalmas időtartam</li>
                                <li>Kedvező árak</li>
                                <li>Szakképzett személyzet tanácsadással</li>
                                <li>Ingyenes szállítás Budapesten belül</li>
                                <li>Biztosítási lehetőség</li>
                            </ul>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-content">
                            <h3>Áraink</h3>
                            <p>Kölcsönzési díjaink a hangszer típusától és a kölcsönzés időtartamától függően változnak.
                            </p>
                            <table class="pricing-table">
                                <thead>
                                    <tr>
                                        <th>Hangszer</th>
                                        <th>1 hónap</th>
                                        <th>3 hónap</th>
                                        <th>6 hónap</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Zongora</td>
                                        <td>15.000 Ft</td>
                                        <td>40.000 Ft</td>
                                        <td>75.000 Ft</td>
                                    </tr>
                                    <tr>
                                        <td>Gitár</td>
                                        <td>5.000 Ft</td>
                                        <td>13.000 Ft</td>
                                        <td>24.000 Ft</td>
                                    </tr>
                                    <tr>
                                        <td>Hegedű</td>
                                        <td>7.000 Ft</td>
                                        <td>18.000 Ft</td>
                                        <td>33.000 Ft</td>
                                    </tr>
                                    <tr>
                                        <td>Fuvola</td>
                                        <td>4.000 Ft</td>
                                        <td>10.000 Ft</td>
                                        <td>18.000 Ft</td>
                                    </tr>
                                    <tr>
                                        <td>Szaxofon</td>
                                        <td>8.000 Ft</td>
                                        <td>21.000 Ft</td>
                                        <td>39.000 Ft</td>
                                    </tr>
                                    <tr>
                                        <td>Trombita</td>
                                        <td>6.000 Ft</td>
                                        <td>15.000 Ft</td>
                                        <td>27.000 Ft</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section style="background-color: rgba(139, 90, 43, 0.1);">
            <div class="container">
                <h2 class="section-title">Elérhető hangszereink</h2>
                <div class="instruments-grid">
                    <div class="instrument">
                        <div class="instrument-icon">🎹</div>
                        <h3>Zongorák</h3>
                        <p>Akusztikus és digitális zongorák</p>
                        <p><strong>15.000 Ft/hó</strong></p>
                    </div>
                    <div class="instrument">
                        <div class="instrument-icon">🎸</div>
                        <h3>Gitárok</h3>
                        <p>Akusztikus, elektromos és klasszikus gitárok</p>
                        <p><strong>5.000 Ft/hó</strong></p>
                    </div>
                    <div class="instrument">
                        <div class="instrument-icon">🎻</div>
                        <h3>Hegedűk</h3>
                        <p>Különböző méretű hegedűk</p>
                        <p><strong>7.000 Ft/hó</strong></p>
                    </div>
                    <div class="instrument">
                        <div class="instrument-icon">🎷</div>
                        <h3>Szaxofonok</h3>
                        <p>Alt, tenor és szoprán szaxofonok</p>
                        <p><strong>8.000 Ft/hó</strong></p>
                    </div>
                    <div class="instrument">
                        <div class="instrument-icon">🎺</div>
                        <h3>Trombiták</h3>
                        <p>Különböző hangolású trombiták</p>
                        <p><strong>6.000 Ft/hó</strong></p>
                    </div>
                    <div class="instrument">
                        <div class="instrument-icon">🥁</div>
                        <h3>Dobok</h3>
                        <p>Akusztikus és elektronikus dob felszerelések</p>
                        <p><strong>10.000 Ft/hó</strong></p>
                    </div>
                </div>
            </div>
        </section>

        <section>
            <div class="container">
                <h2 class="section-title">Kölcsönzési kérelm</h2>
                <div class="rental-form">
                    <form id="rentalForm">
                        <div class="form-group">
                            <label for="name">Teljes név *</label>
                            <input type="text" id="name" name="name" required placeholder="Add meg a neved">
                        </div>

                        <div class="form-group">
                            <label for="email">Email cím *</label>
                            <input type="email" id="email" name="email" required placeholder="Add meg az email címed">
                        </div>

                        <div class="form-group">
                            <label for="phone">Telefonszám *</label>
                            <input type="tel" id="phone" name="phone" required placeholder="Add meg a telefonszámod">
                        </div>

                        <div class="form-group">
                            <label for="address">Lakcím *</label>
                            <input type="text" id="address" name="address" required placeholder="Add meg a lakcímed">
                        </div>

                        <div class="form-group">
                            <label for="instrument">Válassz hangszert *</label>
                            <select id="instrument" name="instrument" required>
                                <option value="">Válassz hangszert</option>
                                <option value="zongora">Zongora - 15.000 Ft/hó</option>
                                <option value="gitar">Gitár - 5.000 Ft/hó</option>
                                <option value="hegedu">Hegedű - 7.000 Ft/hó</option>
                                <option value="fuvola">Fuvola - 4.000 Ft/hó</option>
                                <option value="szaxofon">Szaxofon - 8.000 Ft/hó</option>
                                <option value="trombita">Trombita - 6.000 Ft/hó</option>
                                <option value="dob">Dob - 10.000 Ft/hó</option>
                                <option value="egyeb">Egyéb (egyeztetés szükséges)</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="duration">Kölcsönzési időtartam *</label>
                            <select id="duration" name="duration" required>
                                <option value="">Válassz időtartamot</option>
                                <option value="1">1 hónap</option>
                                <option value="3">3 hónap (10% kedvezmény)</option>
                                <option value="6">6 hónap (15% kedvezmény)</option>
                                <option value="12">1 év (20% kedvezmény)</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="start_date">Kölcsönzés kezdete *</label>
                            <input type="date" id="start_date" name="start_date" required>
                        </div>

                        <div class="form-group">
                            <label>
                                <input type="checkbox" name="insurance" id="insurance">
                                Biztosítás kérése (+2.000 Ft/hó)
                            </label>
                        </div>

                        <div class="form-group">
                            <label>
                                <input type="checkbox" name="delivery" id="delivery">
                                Szállítás kérése (Budapesten belül ingyenes)
                            </label>
                        </div>

                        <div class="form-group">
                            <label for="experience">Zenei tapasztalat</label>
                            <select id="experience" name="experience">
                                <option value="">Válassz tapasztalati szintet</option>
                                <option value="kezdo">Kezdő (0-1 év)</option>
                                <option value="kozepfokú">Középhaladó (1-3 év)</option>
                                <option value="halado">Haladó (3+ év)</option>
                                <option value="professzionalis">Professzionális</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="message">Egyéb megjegyzések</label>
                            <textarea id="message" name="message"
                                placeholder="Egyéb kérések, megjegyzések..."></textarea>
                        </div>

                        <div class="form-group">
                            <label>
                                <input type="checkbox" name="terms" id="terms" required>
                                Elfogadom a <a href="#" style="color: #8B5A2B;">kölcsönzési feltételeket</a> *
                            </label>
                        </div>

                        <button type="submit" class="btn">Kölcsönzési kérelem elküldése</button>
                    </form>
                </div>
            </div>
        </section>

        <section style="background-color: rgba(139, 90, 43, 0.1);">
            <div class="container">
                <h2 class="section-title">Gyakran Ismételt Kérdések</h2>
                <div class="cards">
                    <div class="card">
                        <div class="card-content">
                            <h3>Milyen dokumentumokra van szükség?</h3>
                            <p>Személyi igazolvány és lakcímkártya, valamint egy letét összeg befizetése, amely a
                                kölcsönzés végén visszajár.</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-content">
                            <h3>Mennyi a letét összege?</h3>
                            <p>A letét összege a hangszer értékétől függ, általában 1-2 havi bérleti díjjal megegyező
                                összeg.</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-content">
                            <h3>Mi történik, ha a hangszer megsérül?</h3>
                            <p>Kisebb sérüléseket mi javítjuk. Baleset esetén a biztosítás fedez, ha azt választotta.
                            </p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-content">
                            <h3>Lehet-e meghosszabbítani a kölcsönzést?</h3>
                            <p>Igen, a kölcsönzés időtartama bármikor meghosszabbítható, ha a hangszer nem foglalt.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- Hangszerek oldal -->
    <div id="hangszerek" class="page-content <?php echo ($active_page == 'hangszerek') ? 'active' : ''; ?>">
        <section class="page-hero">
            <div class="container">
                <h2>Hangszerek</h2>
                <p>Fedezd fel hangszerkínálatunkat és válassz a minőségi hangszereink közül</p>
            </div>
        </section>

        <section>
            <div class="container">
                <h2 class="section-title">Hangszer Kategóriák</h2>
                <div class="instruments-grid">
                    <div class="instrument">
                        <div class="instrument-icon">🎻</div>
                        <h3>Vonós Hangszerek</h3>
                        <p>Hegedű, brácsa, gordonka, nagybőgő</p>
                        <a href="#" class="btn" data-page="kolcsonzes">Kölcsönzés</a>
                    </div>
                    <div class="instrument">
                        <div class="instrument-icon">🎹</div>
                        <h3>Billentyűs Hangszerek</h3>
                        <p>Zongora, orgona, szintetizátor, billentyűsök</p>
                        <a href="#" class="btn" data-page="kolcsonzes">Kölcsönzés</a>
                    </div>
                    <div class="instrument">
                        <div class="instrument-icon">🎸</div>
                        <h3>Pengetős Hangszerek</h3>
                        <p>Gitár, basszusgitár, hárfa, ukulele</p>
                        <a href="#" class="btn" data-page="kolcsonzes">Kölcsönzés</a>
                    </div>
                    <div class="instrument">
                        <div class="instrument-icon">🎷</div>
                        <h3>Fúvós Hangszerek</h3>
                        <p>Szaxofon, trombita, fuvola, klarinét</p>
                        <a href="#" class="btn" data-page="kolcsonzes">Kölcsönzés</a>
                    </div>
                    <div class="instrument">
                        <div class="instrument-icon">🥁</div>
                        <h3>Ütős Hangszerek</h3>
                        <p>Dobok, üstdobok, xilofon, kongák</p>
                        <a href="#" class="btn" data-page="kolcsonzes">Kölcsönzés</a>
                    </div>
                    <div class="instrument">
                        <div class="instrument-icon">🎤</div>
                        <h3>Énektanítás</h3>
                        <p>Mikrofonok, erősítők, hangtechnika</p>
                        <a href="#" class="btn" data-page="kolcsonzes">Kölcsönzés</a>
                    </div>
                </div>
            </div>
        </section>

        <section style="background-color: rgba(139, 90, 43, 0.1);">
            <div class="container">
                <h2 class="section-title">Népszerű Hangszereink</h2>
                <div class="cards">
                    <div class="card">
                        <div class="card-img"
                            style="background-image: url('https://images.unsplash.com/photo-1520523839897-bd0b52f945a0?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')">
                        </div>
                        <div class="card-content">
                            <h3>Yamaha C3 Zongora</h3>
                            <p>Professzionális koncert zongora kiváló hanggal és érintéssel. Ideális haladó és
                                professzionális zongoristák számára.</p>
                            <div class="specs">
                                <p><strong>Ár:</strong> 15.000 Ft/hó</p>
                                <p><strong>Állapot:</strong> Kiváló</p>
                                <p><strong>Évjárat:</strong> 2020</p>
                            </div>
                            <a href="#" class="btn" data-page="kolcsonzes">Kölcsönzés</a>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-img"
                            style="background-image: url('https://images.unsplash.com/photo-1558098329-a11cff621064?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')">
                        </div>
                        <div class="card-content">
                            <h3>Fender Stratocaster Gitár</h3>
                            <p>Klasszikus elektromos gitár ikonikus hanggal. Tökéletes rock, blues és pop stílusokhoz.
                            </p>
                            <div class="specs">
                                <p><strong>Ár:</strong> 5.000 Ft/hó</p>
                                <p><strong>Állapot:</strong> Újszerű</p>
                                <p><strong>Évjárat:</strong> 2021</p>
                            </div>
                            <a href="#" class="btn" data-page="kolcsonzes">Kölcsönzés</a>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-img"
                            style="background-image: url('https://images.unsplash.com/photo-1519892300165-cb5542fb47c7?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')">
                        </div>
                        <div class="card-content">
                            <h3>Yamaha YAS-62 Szaxofon</h3>
                            <p>Professzionális alt szaxofon gazdag, meleg hanggal. Szólista és zenekari használatra
                                egyaránt.</p>
                            <div class="specs">
                                <p><strong>Ár:</strong> 8.000 Ft/hó</p>
                                <p><strong>Állapot:</strong> Kitűnő</p>
                                <p><strong>Évjárat:</strong> 2019</p>
                            </div>
                            <a href="#" class="btn" data-page="kolcsonzes">Kölcsönzés</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section>
            <div class="container">
                <h2 class="section-title">Hangszer Vásárlás</h2>
                <div class="highlight-section">
                    <h3>Új és használt hangszerek eladó</h3>
                    <p>Nemcsak kölcsönzünk, hanem értékesítünk is hangszereket! Tekintsd meg kínálatunkat és vásárolj
                        magadnak tökéletes hangszert.</p>
                    <div class="cards">
                        <div class="card">
                            <div class="card-content">
                                <h4>Új Hangszerek</h4>
                                <p>Garanciás, csomagolásban lévő új hangszerek vezető márkáktól.</p>
                                <ul class="feature-list">
                                    <li>2 év gyártói garancia</li>
                                    <li>Ingyenes beállítás</li>
                                    <li>Részletfizetési lehetőség</li>
                                </ul>
                                <a href="#" class="btn">Új hangszerek</a>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-content">
                                <h4>Használt Hangszerek</h4>
                                <p>Minőségi, felújított használt hangszerek kedvező áron.</p>
                                <ul class="feature-list">
                                    <li>Alapos felújítás</li>
                                    <li>6 hónap garancia</li>
                                    <li>Csere lehetőség</li>
                                </ul>
                                <a href="#" class="btn">Használt hangszerek</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- Események oldal -->
    <div id="esemenyek" class="page-content <?php echo ($active_page == 'esemenyek') ? 'active' : ''; ?>">
        <section class="page-hero">
            <div class="container">
                <h2>Események</h2>
                <p>Válogatott zenei események, koncertek és mesterkurzusok</p>
            </div>
        </section>

        <section>
            <div class="container">
                <h2 class="section-title">Közelgő Események</h2>
                <div class="events-list">
                    <div class="event">
                        <div class="event-date">
                            <span class="day">15</span>
                            <span class="month">Máj</span>
                        </div>
                        <div class="event-info">
                            <h3>Tanulói Tavaszi Koncert</h3>
                            <p>Diákjaink bemutatkozó koncertje a zeneiskola nagytermében. Lépj színpadra és mutasd meg
                                tehetséged!</p>
                            <p><strong>Időpont:</strong> 18:00 | <strong>Helyszín:</strong> Zeneiskola Nagytér</p>
                            <p><strong>Részvétel:</strong> Ingyenes</p>
                            <a href="#" class="btn">Jelentkezem</a>
                        </div>
                    </div>

                    <div class="event">
                        <div class="event-date">
                            <span class="day">22</span>
                            <span class="month">Máj</span>
                        </div>
                        <div class="event-info">
                            <h3>Mesterkurzus Gitáron</h3>
                            <p>Híres gitárművész, Nagy Péter tart mesterkurzust haladó gitárosok számára. Ismerd meg a
                                professzionális technikákat!</p>
                            <p><strong>Időpont:</strong> 14:00 - 17:00 | <strong>Helyszín:</strong> 101. Stúdió</p>
                            <p><strong>Ár:</strong> 8.000 Ft</p>
                            <a href="#" class="btn">Jelentkezés</a>
                        </div>
                    </div>

                    <div class="event">
                        <div class="event-date">
                            <span class="day">05</span>
                            <span class="month">Jún</span>
                        </div>
                        <div class="event-info">
                            <h3>Nyílt Nap a Zeneiskolában</h3>
                            <p>Ismerd meg zeneiskolánkat, találkozz tanárainkkal és próbálj ki különböző hangszereket.
                                Családbarát program!</p>
                            <p><strong>Időpont:</strong> 10:00 - 16:00 | <strong>Helyszín:</strong> Egész zeneiskola</p>
                            <p><strong>Részvétel:</strong> Ingyenes</p>
                            <a href="#" class="btn">Részletek</a>
                        </div>
                    </div>

                    <div class="event">
                        <div class="event-date">
                            <span class="day">18</span>
                            <span class="month">Jún</span>
                        </div>
                        <div class="event-info">
                            <h3>Zongora Verseny</h3>
                            <p>Éves zongoraversenyünk minden korosztály számára. Mutasd meg tudásodat és nyerj értékes
                                díjakat!</p>
                            <p><strong>Időpont:</strong> 09:00 - 18:00 | <strong>Helyszín:</strong> Koncertterem</p>
                            <p><strong>Nevezési díj:</strong> 5.000 Ft</p>
                            <a href="#" class="btn">Nevezés</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section style="background-color: rgba(139, 90, 43, 0.1);">
            <div class="container">
                <h2 class="section-title">Rendszeres Programjaink</h2>
                <div class="cards">
                    <div class="card">
                        <div class="card-content">
                            <h3>Közös Zene Óra</h3>
                            <p><strong>Minden szerda 17:00</strong></p>
                            <p>Csoportos zeneóra, ahol együtt játszhatsz más zenészekkel. Tökéletes lehetőség a zenekari
                                gyakorlathoz.</p>
                            <p><strong>Ár:</strong> 2.000 Ft/alkalom</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-content">
                            <h3>Zenei Esték</h3>
                            <p><strong>Minden péntek 19:00</strong></p>
                            <p>Laza hangulatú zenei esték, ahol hallgathatsz és zenélhetsz is. Nyitott színpad mindenki
                                számára.</p>
                            <p><strong>Ár:</strong> Ingyenes</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-content">
                            <h3>Zeneelméleti Kör</h3>
                            <p><strong>Minden kedd 16:00</strong></p>
                            <p>Mélyebb betekintés a zeneelmélet rejtelmeibe. Akár kezdő, akár haladó szinten vagy, itt a
                                helyed.</p>
                            <p><strong>Ár:</strong> 1.500 Ft/alkalom</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section>
            <div class="container">
                <h2 class="section-title">Esemény jelentkezés</h2>
                <div class="rental-form">
                    <form id="eventForm">
                        <div class="form-group">
                            <label for="event_name">Esemény kiválasztása *</label>
                            <select id="event_name" name="event_name" required>
                                <option value="">Válassz eseményt</option>
                                <option value="tanuloi_koncert">Tanulói Tavaszi Koncert - Május 15.</option>
                                <option value="mesterkurzus_gitar">Mesterkurzus Gitáron - Május 22.</option>
                                <option value="nyilt_nap">Nyílt Nap - Június 5.</option>
                                <option value="zongora_verseny">Zongora Verseny - Június 18.</option>
                                <option value="kozos_zene_ora">Közös Zene Óra - Szerda 17:00</option>
                                <option value="zenei_estek">Zenei Esték - Péntek 19:00</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="participant_name">Résztvevő neve *</label>
                            <input type="text" id="participant_name" name="participant_name" required
                                placeholder="Add meg a neved">
                        </div>

                        <div class="form-group">
                            <label for="participant_email">Email cím *</label>
                            <input type="email" id="participant_email" name="participant_email" required
                                placeholder="Add meg az email címed">
                        </div>

                        <div class="form-group">
                            <label for="participant_phone">Telefonszám</label>
                            <input type="tel" id="participant_phone" name="participant_phone"
                                placeholder="Add meg a telefonszámod">
                        </div>

                        <div class="form-group">
                            <label for="participant_age">Korcsoport</label>
                            <select id="participant_age" name="participant_age">
                                <option value="">Válassz korcsoportot</option>
                                <option value="6-12">6-12 év</option>
                                <option value="13-18">13-18 év</option>
                                <option value="19-25">19-25 év</option>
                                <option value="26-40">26-40 év</option>
                                <option value="40+">40+ év</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="instrument">Milyen hangszeren játszol?</label>
                            <input type="text" id="instrument" name="instrument"
                                placeholder="Pl.: zongora, gitár, hegedű...">
                        </div>

                        <div class="form-group">
                            <label for="experience_level">Tapasztalati szint</label>
                            <select id="experience_level" name="experience_level">
                                <option value="">Válassz szintet</option>
                                <option value="kezdo">Kezdő</option>
                                <option value="kozepfoku">Középhaladó</option>
                                <option value="halado">Haladó</option>
                                <option value="professzionalis">Professzionális</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="special_requests">Különleges kérések</label>
                            <textarea id="special_requests" name="special_requests"
                                placeholder="Egyéb megjegyzések, speciális igények..."></textarea>
                        </div>

                        <button type="submit" class="btn">Jelentkezés elküldése</button>
                    </form>
                </div>
            </div>
        </section>
    </div>

    <!-- Kapcsolat oldal -->
    <div id="kapcsolat" class="page-content <?php echo ($active_page == 'kapcsolat') ? 'active' : ''; ?>">
        <section class="page-hero">
            <div class="container">
                <h2>Kapcsolat</h2>
                <p>Lépj velünk kapcsolatba - szívesen válaszolunk minden kérdésedre</p>
            </div>
        </section>

        <section>
            <div class="container">
                <div class="cards">
                    <div class="card">
                        <div class="card-content">
                            <h3>📞 Telefon</h3>
                            <p><strong>+36 1 234 5678</strong></p>
                            <p>Hétfő - Péntek: 9:00 - 18:00</p>
                            <p>Szombat: 10:00 - 14:00</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-content">
                            <h3>📧 Email</h3>
                            <p><strong>info@zeneljvelunk.hu</strong></p>
                            <p>Általános információk</p>
                            <p><strong>tanitas@zeneljvelunk.hu</strong></p>
                            <p>Oktatási ügyek</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-content">
                            <h3>📍 Cím</h3>
                            <p><strong>1056 Budapest, Zene utca 12.</strong></p>
                            <p>Központi helyen, könnyen megközelíthető</p>
                            <p>Metró: Deák Ferenc tér</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section style="background-color: rgba(139, 90, 43, 0.1);">
            <div class="container">
                <h2 class="section-title">Írj nekünk!</h2>
                <div class="rental-form">
                    <form id="contactForm">
                        <div class="form-group">
                            <label for="contact_name">Név *</label>
                            <input type="text" id="contact_name" name="contact_name" required
                                placeholder="Add meg a neved">
                        </div>

                        <div class="form-group">
                            <label for="contact_email">Email cím *</label>
                            <input type="email" id="contact_email" name="contact_email" required
                                placeholder="Add meg az email címed">
                        </div>

                        <div class="form-group">
                            <label for="contact_phone">Telefonszám</label>
                            <input type="tel" id="contact_phone" name="contact_phone"
                                placeholder="Add meg a telefonszámod">
                        </div>

                        <div class="form-group">
                            <label for="contact_subject">Tárgy *</label>
                            <select id="contact_subject" name="contact_subject" required>
                                <option value="">Válassz tárgyat</option>
                                <option value="tanfolyam">Tanfolyam információk</option>
                                <option value="kolcsonzes">Hangszerkölcsönzés</option>
                                <option value="vasarlas">Hangszer vásárlás</option>
                                <option value="esemeny">Esemény jelentkezés</option>
                                <option value="egyeb">Egyéb</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="contact_message">Üzenet *</label>
                            <textarea id="contact_message" name="contact_message" required
                                placeholder="Írd le üzeneted..." rows="6"></textarea>
                        </div>

                        <div class="form-group">
                            <label>
                                <input type="checkbox" name="newsletter" id="newsletter">
                                Szeretnék hírlevelet kapni az aktuális eseményekről és akciókról
                            </label>
                        </div>

                        <button type="submit" class="btn">Üzenet elküldése</button>
                    </form>
                </div>
            </div>
        </section>

        <section>
            <div class="container">
                <h2 class="section-title">Elérhetőségeink</h2>
                <div class="cards">
                    <div class="card">
                        <div class="card-content">
                            <h3>🚗 Megközelíthetőség</h3>
                            <p><strong>Tömegközlekedéssel:</strong></p>
                            <ul class="feature-list">
                                <li>Metró: M1, M2, M3 - Deák Ferenc tér</li>
                                <li>Bus: 5, 7, 8E, 110, 112</li>
                                <li>Villamos: 47, 49</li>
                            </ul>
                            <p><strong>Autóval:</strong></p>
                            <p>Közeli parkolók: Deák Ferenc tér parkoló, Városháza parkoló</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-content">
                            <h3>🕒 Nyitvatartás</h3>
                            <p><strong>Hétfő - Péntek:</strong> 9:00 - 18:00</p>
                            <p><strong>Szombat:</strong> 10:00 - 14:00</p>
                            <p><strong>Vasárnap:</strong> Zárt</p>
                            <p><strong>Ünnepnapokon:</strong> Zárt</p>
                            <div class="highlight-section"
                                style="margin-top: 1rem; padding: 1rem; background-color: rgba(139, 90, 43, 0.1); border-radius: 5px;">
                                <p><strong>Figyelem:</strong> Nyári nyitvatartás július 15-től augusztus 15-ig:</p>
                                <p>Hétfő - Péntek: 10:00 - 16:00</p>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-content">
                            <h3>👥 Csapatunk</h3>
                            <p><strong>Igazgató:</strong> Kovács Anna</p>
                            <p><strong>Oktatás vezető:</strong> Nagy Péter</p>
                            <p><strong>Kölcsönzés:</strong> Szabó Eszter</p>
                            <p><strong>Adminisztráció:</strong> Tóth Gábor</p>
                            <p>Szakképzett, segítőkész csapatunk mindig a rendelkezésedre áll!</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section style="background-color: rgba(139, 90, 43, 0.1);">
            <div class="container">
                <h2 class="section-title">Térkép</h2>
                <div style="background-color: white; border-radius: 10px; box-shadow: var(--shadow); overflow: hidden;">
                    <!-- A te stílusoddal illeszkedő verzió -->
                    <div
                        style="background-color: white; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1); margin: 2rem 0;">
                        <div style="height: 400px;">
                            <iframe
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2695.572294238238!2d19.04021577648277!3d47.49790307117939!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4741dc3d45186d6f%3A0xb3411a1ae5e49f1e!2sBudapest%2C%20De%C3%A1k%20Ferenc%20t%C3%A9r%2C%201055!5e0!3m2!1shu!2shu!4v1700000000000!5m2!1shu!2shu"
                                width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade">
                            </iframe>
                        </div>
                        <div style="padding: 1.5rem; text-align: center; background-color: #f8f9fa;">
                            <h3 style="color: #8B5A2B; margin-bottom: 0.5rem;">Zenélj Velünk Zeneiskola</h3>
                            <p style="margin: 0; color: #5D4037;">1056 Budapest, Zene utca 12.</p>
                            <a href="https://maps.google.com/?q=1056+Budapest,+Zene+utca+12." target="_blank"
                                style="display: inline-block; margin-top: 1rem; padding: 0.5rem 1rem; background-color: #8B5A2B; color: white; text-decoration: none; border-radius: 5px;">
                                🗺️ Térkép megnyitása
                            </a>
                        </div>
                    </div>
                </div>
        </section>
    </div>

    <!-- További oldalak... (ugyanígy folytasd a többit is) -->

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Kapcsolat</h3>
                    <p>Zenélj Velünk Zeneiskola</p>
                    <p>1056 Budapest, Zene utca 12.</p>
                    <p>Telefon: +36 1 234 5678</p>
                    <p>Email: info@zeneljvelunk.hu</p>
                </div>
                <div class="footer-section">
                    <h3>Nyitvatartás</h3>
                    <p>Hétfő - Péntek: 9:00 - 18:00</p>
                    <p>Szombat: 10:00 - 14:00</p>
                    <p>Vasárnap: Zárt</p>
                </div>
                <div class="footer-section">
                    <h3>Gyors linkek</h3>
                    <ul>
                        <li><a href="#" data-page="home">Kezdőlap</a></li>
                        <li><a href="#" data-page="zeneiskola">Zeneiskola</a></li>
                        <li><a href="#" data-page="tanarok">Tanárok</a></li>
                        <li><a href="#" data-page="kolcsonzes">Kölcsönzés</a></li>
                        <li><a href="#" data-page="hangszerek">Hangszerek</a></li>
                        <li><a href="#" data-page="esemenyek">Események</a></li>
                    </ul>
                </div>
            </div>
            <div class="copyright">
                <p>&copy; 2025 Zenélj Velünk Zeneiskola. Minden jog fenntartva.</p>
            </div>
        </div>
    </footer>

    <script>
        // Oldalak közötti navigáció
        document.querySelectorAll('nav a, .footer-section a, .btn').forEach(link => {
            link.addEventListener('click', function (e) {
                e.preventDefault();
                const targetPage = this.getAttribute('data-page');

                if (targetPage) {
                    // Összes oldal elrejtése
                    document.querySelectorAll('.page-content').forEach(page => {
                        page.classList.remove('active');
                    });

                    // Céloldal megjelenítése
                    document.getElementById(targetPage).classList.add('active');

                    // Mobilon bezárjuk a menüt
                    if (window.innerWidth <= 768) {
                        document.getElementById('main-menu').classList.remove('show');
                    }

                    // Oldal tetejére görbünk
                    window.scrollTo(0, 0);

                    // URL frissítése
                    history.pushState(null, null, `?p=${targetPage}`);
                }
            });
        });

        // Mobilos menü kezelése
        document.querySelector('.mobile-menu-btn').addEventListener('click', function () {
            document.getElementById('main-menu').classList.toggle('show');
        });

        // Kölcsönzési űrlap kezelése
        const rentalForm = document.getElementById('rentalForm');
        if (rentalForm) {
            rentalForm.addEventListener('submit', function (e) {
                e.preventDefault();
                alert('Köszönjük kölcsönzési kérelmét! Hamarosan felvesszük Önnel a kapcsolatot.');
                this.reset();
            });
        }
    </script>

</body>

</html>