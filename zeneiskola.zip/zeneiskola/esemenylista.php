<?php

include('connect.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
$esemeny_nev= $_POST['esemeny_nev'];
$esemeny_leirasa= $_POST['esemeny_leirasa'];
$iskola= $_POST['iskola'];
$kapcsolattarto= $_POST['kapcsolattarto'];
$helyszin= $_POST['helyszin']; 
$idopont= $_POST['idopont'] ;

    $sql = "INSERT INTO esemenyek (esemeny_nev, esemeny_leirasa, iskola, kapcsolattarto, helyszin, idopont) 
            VALUES ('$esemeny_nev', '$esemeny_leirasa', '$iskola', '$kapcsolattarto', '$helyszin', '$idopont')"; 

    if ($conn->query($sql) === TRUE) {
        echo "<p style='color:green;'>Sikeres mentés!</p>";
    } else {
        echo "<p style='color:red;'>Hiba: " . $conn->error . "</p>";
    }
}

$conn->close();
?>
 <form action="" method="post">
      <h2>Esemény hozzáadása</h2>

      <div class="input-field">
        <label>Esemény név:</label>
        <input type="text" name="esemeny_nev" required />
        
      </div>

      <div class="input-field">
        <label>Esemény leírása:</label>
        <input type="text" name="esemeny_leirasa" required />
        
      </div>

      <div class="input-field">
        <label>Iskola:</label>
        <input type="text" name="iskola" required />
        
      </div>

      <div class="input-field">
        <label>kapcsolattartó:</label>
        <input type="text" name="kapcsolattarto" required />
        
      </div>

      <div class="input-field">
        <label>Helyszin:</label>
        <input type="text" name="helyszin" required />
        
      </div>

      <div class="input-field">
        <label>Időpont:</label>
        <input type="text" name="idopont" required />
        
      </div>
 
      <button type="submit" id="button" >Elküldés</button>

</form>