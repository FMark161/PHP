<?php

include('connect.php');




if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
$nev= $_POST['nev'];
$szuletesi_datum= $_POST['szuletesi_datum'];
$telefonszam= $_POST['telefonszam'];
$iskolaid= $_POST['iskolaid'];
$kolcsonzott_hangszerek= $_POST['kolcsonzott_hangszerek'];   

    $sql = "INSERT INTO diak (nev, szuletesi_datum, telefonszam, iskolaid, kolcsonzott_hangszerek) 
            VALUES ('$nev', '$szuletesi_datum', '$telefonszam', '$iskolaid', '$kolcsonzott_hangszerek')"; 

    if ($conn->query($sql) === TRUE) {
        echo "<p style='color:green;'>Sikeres mentés!</p>";
    } else {
        echo "<p style='color:red;'>Hiba: " . $conn->error . "</p>";
    }
}

$conn->close();
?>
 <form action="" method="post">
      <h2>Diák hozzáadása</h2>

      <div class="input-field">
        <label>Név:</label>
        <input type="text" name="nev" required />
        
      </div>

      <div class="input-field">
        <label>Születési Dátum:</label>
        <input type="text" name="szuletesi_datum" required />
        
      </div>

      <div class="input-field">
        <label>Telefonszám:</label>
        <input type="text" name="telefonszam" required />
        
      </div>

      <div class="input-field">
        <label>Iskola_id:</label>
        <input type="text" name="iskolaid" required />
        
      </div>

      <div class="input-field">
        <label>Kölcsönzött hangszerek:</label>
        <input type="text" name="kolcsonzott_hangszerek" required />
        
      </div>
 
      <button type="submit" id="button" >Elküldés</button>

</form>