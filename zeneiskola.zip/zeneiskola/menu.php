<?php
$sql = "SELECT * FROM menu ORDER BY sorrend, id";
$result = $conn->query($sql);

function h($v)
{
    return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
}
?>

<ul id="main-menu">
    <?php if ($result && $result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
            <li>
                <a href="index.php?p=<?php echo urlencode($row['link']); ?>" data-page="<?php echo h($row['link']); ?>">
                    <?php echo h($row['nev']); ?>
                </a>
            </li>
        <?php endwhile; ?>
    <?php else: ?>
        <!-- Alapértelmezett menüpontok, ha nincs adat az adatbázisban -->
        <li><a href="#" data-page="home">Kezdőlap</a></li>
        <li><a href="#" data-page="zeneiskola">Zeneiskola</a></li>
        <li><a href="#" data-page="tanarok">Tanárok</a></li>
        <li><a href="#" data-page="kolcsonzes">Kölcsönzés</a></li>
        <li><a href="#" data-page="hangszerek">Hangszerek</a></li>
        <li><a href="#" data-page="esemenyek">Események</a></li>
        <li><a href="#" data-page="kapcsolat">Kapcsolat</a></li>
    <?php endif; ?>
</ul>